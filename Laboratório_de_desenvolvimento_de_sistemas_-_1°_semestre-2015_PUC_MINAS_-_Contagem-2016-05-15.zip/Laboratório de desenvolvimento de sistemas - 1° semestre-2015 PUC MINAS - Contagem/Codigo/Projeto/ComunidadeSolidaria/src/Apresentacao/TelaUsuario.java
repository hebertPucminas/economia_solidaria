/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apresentacao;

import Dominio.Comunidade;
import Dominio.Consumidor;
import Dominio.Endereco;
import Dominio.Pedido;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Vector;
import javax.swing.JOptionPane;

public class TelaUsuario extends javax.swing.JFrame {

    private int idProdutor = 0;
    Comunidade comunidade;
    private int id_Produto = 0;
    private String descricao;
    private Consumidor consumidorCorrente;

    public TelaUsuario(Comunidade controladora) {
        initComponents();
        this.comunidade = controladora;
        CampoTotal.setText("");

    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getIdProdutor() {
        return idProdutor;
    }

    public void setIdProdutor(int idProdutor) {
        this.idProdutor = idProdutor;
    }

    public void atualizarCampo(int id, String descricao, int idProdutor) {
        CampoDescricao.setText(descricao);
        this.descricao = descricao;
        this.id_Produto = id;
        this.idProdutor = idProdutor;

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BotaoAdicionar = new javax.swing.JButton();
        CampoQtd = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        BotaoFinalizar = new javax.swing.JButton();
        BotaoPagamento = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        CampoTotal = new javax.swing.JLabel();
        CampoLogradouro = new javax.swing.JTextField();
        CampoNumero = new javax.swing.JTextField();
        CampoBairro = new javax.swing.JTextField();
        CampoCidade = new javax.swing.JTextField();
        CampoEstado = new javax.swing.JTextField();
        CampoCEP = new javax.swing.JTextField();
        BotaoSelecionarEndereco = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        ComboFormaPagamento = new javax.swing.JComboBox();
        jLabel12 = new javax.swing.JLabel();
        CampoDescricao = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("*** Comunidade Solidária **** Store ");
        setName("Comunidade Solidária Store"); // NOI18N

        BotaoAdicionar.setText("Adicionar ao Carrinho");
        BotaoAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoAdicionarActionPerformed(evt);
            }
        });

        jLabel2.setText("  Quantidade");

        jLabel3.setText("Descrição:");
        jLabel3.setToolTipText("");

        BotaoFinalizar.setText("Finalizar");
        BotaoFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoFinalizarActionPerformed(evt);
            }
        });

        BotaoPagamento.setText("Efetuar Pagamento");
        BotaoPagamento.setActionCommand("");
        BotaoPagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoPagamentoActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Total (R$): ");

        CampoTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CampoTotal.setText("00.00");

        CampoLogradouro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampoLogradouroActionPerformed(evt);
            }
        });

        BotaoSelecionarEndereco.setText("Confirmar endereço");
        BotaoSelecionarEndereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoSelecionarEnderecoActionPerformed(evt);
            }
        });

        jLabel6.setText("Logradouro:");

        jLabel7.setText("Número:");

        jLabel8.setText("Bairro:");

        jLabel9.setText("Cidade:");

        jLabel10.setText("Estado:");

        jLabel11.setText("CEP:");

        ComboFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Moeda solidária", "Moeda corrente", "Cartão de crédito", "Boleto" }));
        ComboFormaPagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboFormaPagamentoActionPerformed(evt);
            }
        });

        jLabel12.setText("Forma pagamento:");

        CampoDescricao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampoDescricaoActionPerformed(evt);
            }
        });

        jButton1.setText("Esvaziar Carrinho");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Buscar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(BotaoSelecionarEndereco)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addGap(139, 139, 139)
                                        .addComponent(jLabel9))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(CampoBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(CampoCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(CampoLogradouro, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(CampoEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(CampoCEP))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel11)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ComboFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(BotaoPagamento)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(CampoDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                                .addComponent(jButton2))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(67, 67, 67)
                                                .addComponent(CampoQtd, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(9, 9, 9)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(BotaoFinalizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(BotaoAdicionar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(44, 44, 44)
                                                .addComponent(jLabel4)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(CampoTotal))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(62, 62, 62)
                                                .addComponent(jButton1)))))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(CampoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7)))
                        .addGap(83, 83, 83))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotaoAdicionar)
                    .addComponent(CampoQtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(CampoTotal))
                    .addComponent(BotaoFinalizar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CampoDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CampoLogradouro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CampoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CampoBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CampoCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CampoEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CampoCEP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addComponent(BotaoSelecionarEndereco)
                .addGap(42, 42, 42)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotaoPagamento)
                    .addComponent(ComboFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        BotaoAdicionar.getAccessibleContext().setAccessibleName("Adicionar Compra");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BotaoAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoAdicionarActionPerformed
        if (CampoDescricao.getText() != null) {
            if (CampoQtd.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Campo Quantidade é obrigatório", "Estoque", 0);
            } else {
                int qtd = Integer.parseInt(CampoQtd.getText());
                if (this.comunidade.adicionarCompra(id_Produto, descricao, qtd) == true) {
                    DecimalFormat df = new DecimalFormat("0.00");
                    CampoTotal.setText(df.format(this.comunidade.obterTotal()));

                }
                CampoDescricao.setText("");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Indisponível no momento.", "Estoque", 0);
        }

        CampoQtd.setText("");
    }//GEN-LAST:event_BotaoAdicionarActionPerformed

    private void BotaoFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoFinalizarActionPerformed
        boolean situacao;
        // verifica  em acesso se o usuario tem login e se está criado.
        situacao = false;

        if (situacao == false) {
            // System.out.println("Teste");
            //TelaLogin login = new TelaLogin();
            //login.setVisible(situacao);
            this.comunidade.login();
            this.comunidade.finalizar(comunidade.getConsumidorCorrente().getIdConsumidor(), idProdutor);
            this.idProdutor = 0;
            DecimalFormat df = new DecimalFormat("0.00");
            CampoTotal.setText(df.format(this.comunidade.obterTotal()));

        } else {
            this.comunidade.finalizar(comunidade.getConsumidorCorrente().getIdConsumidor(), idProdutor);
            this.idProdutor = 0;
            DecimalFormat df = new DecimalFormat("0.00");
            CampoTotal.setText(df.format(this.comunidade.obterTotal()));

        }

    }//GEN-LAST:event_BotaoFinalizarActionPerformed

    private void BotaoSelecionarEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoSelecionarEnderecoActionPerformed

        if (CampoLogradouro.getText().equals("") || CampoNumero.getText().equals("") || CampoBairro.getText().equals("") || CampoCidade.getText().equals("") || CampoEstado.getText().equals("") || CampoCEP.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        } else {
            String rua, numero, bairro, cidade, estado, cep;
            rua = CampoLogradouro.getText();
            bairro = CampoBairro.getText();
            cidade = CampoCidade.getText();
            estado = CampoEstado.getText();
            numero = CampoNumero.getText();
            cep = CampoCEP.getText();

            comunidade.definirEndereco(rua, numero, bairro, cidade, estado, cep);
            //Endereco e = new Endereco(rua, numero, bairro, cidade, estado, cep);
            JOptionPane.showMessageDialog(null, "Endereco para entrega cadastrado");
            CampoLogradouro.setText(null);
            CampoNumero.setText(null);
            CampoBairro.setText(null);
            CampoCidade.setText(null);
            CampoEstado.setText(null);
            CampoCEP.setText(null);
        }
    }//GEN-LAST:event_BotaoSelecionarEnderecoActionPerformed

    private void BotaoPagamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoPagamentoActionPerformed
        int opcao = ComboFormaPagamento.getSelectedIndex();
        switch (opcao) {
            case 0: {
                this.comunidade.efetuarPagamento(1);
                CampoTotal.setText(Double.toString(this.comunidade.obterTotal()));
            }
            break;
            case 1: {
                this.comunidade.efetuarPagamento(2);
                CampoTotal.setText(Double.toString(this.comunidade.obterTotal()));
            }
            case 2: {
                this.comunidade.efetuarPagamento(3);
                CampoTotal.setText(Double.toString(this.comunidade.obterTotal()));
            }
            case 3: {
                this.comunidade.efetuarPagamento(4);
                CampoTotal.setText(Double.toString(this.comunidade.obterTotal()));
            }

            default: {
                break;
            }
        }
    }//GEN-LAST:event_BotaoPagamentoActionPerformed

    private void CampoLogradouroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CampoLogradouroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CampoLogradouroActionPerformed

    private void ComboFormaPagamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboFormaPagamentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboFormaPagamentoActionPerformed

    private void CampoDescricaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CampoDescricaoActionPerformed
//        if (!CampoDescricao.getText().equals("")) {
//           
//            
//            
//            if (str != null) {
//                CampoDescricao.setText(str);
//            } else {
//                JOptionPane.showMessageDialog(null, "Sua pesquisa não retornou resultado", "Alerta", 1);
//            }
//        } else {
//            JOptionPane.showMessageDialog(null, "Selecione um produto", "Alerta", 0);
//        }

    }//GEN-LAST:event_CampoDescricaoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        comunidade.desistirDaCompra();
        DecimalFormat df = new DecimalFormat("0.00");
        CampoTotal.setText(df.format(this.comunidade.obterTotal()));
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        if (!CampoDescricao.getText().equals("")) {
            new Produtos(comunidade.pesquisar(CampoDescricao.getText(), idProdutor), this, idProdutor);
        } else {
            JOptionPane.showMessageDialog(null, "Campo pesquisa vazio!");
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    public void setId_Produto(int id_Produto) {
        this.id_Produto = id_Produto;

    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotaoAdicionar;
    private javax.swing.JButton BotaoFinalizar;
    private javax.swing.JButton BotaoPagamento;
    private javax.swing.JButton BotaoSelecionarEndereco;
    private javax.swing.JTextField CampoBairro;
    private javax.swing.JTextField CampoCEP;
    private javax.swing.JTextField CampoCidade;
    private javax.swing.JTextField CampoDescricao;
    private javax.swing.JTextField CampoEstado;
    private javax.swing.JTextField CampoLogradouro;
    private javax.swing.JTextField CampoNumero;
    private javax.swing.JTextField CampoQtd;
    private javax.swing.JLabel CampoTotal;
    private javax.swing.JComboBox ComboFormaPagamento;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
