/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Apresentacao.*;
import DAO.Conexao;
import Dominio.Comunidade;
import Dominio.Acesso;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author André Mendonça
 */
public class Main {

    public static void main(String[] args) {
        Conexao.getInstancia().Conectar();

        TelaUsuario telaPrincipal = new TelaUsuario(new Comunidade());
        telaPrincipal.setVisible(true);
        
        
       
        
        
       
        

    }


    public static void leitor(List<Object[]> lista) {
        for (Object[] linha : lista) {
            for (int i = 0; i < linha.length; i++) {
                System.out.print(linha[i] + " ");
            }
            System.out.println("");
        }

    }
}
