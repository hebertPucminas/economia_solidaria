package Principal;

import DAO.Conexao;
import Dominio.Bem;
import Dominio.Comunidade;

public class MainOfertaDeBem {

    private static final int idBem = 11;
    private static final int idLoja = 1;
    private static final int categoria = 1;

    private static final int situacao = 1;
    private static Comunidade comunidade;

    public static void main(String[] args) {
        Conexao.getInstancia().Conectar();
        comunidade = new Comunidade();
        //Cria um bem de teste para inserção
        Bem bem = new Bem(idBem, "Produto do dellan", "Descricao do Bem", "Marca do bem", 100.00D, categoria, "URL da Imagem", "Endereco Fisico", "Endereco Virtual", idLoja, situacao);
        
       
        //Simula a inserção de um novo bem por um produtor
        comunidade.inserirBem(bem);
        
        //Simula a remoção de um bem por um produtor
        //comunidade.deletarBem(bem);      
    }
}
