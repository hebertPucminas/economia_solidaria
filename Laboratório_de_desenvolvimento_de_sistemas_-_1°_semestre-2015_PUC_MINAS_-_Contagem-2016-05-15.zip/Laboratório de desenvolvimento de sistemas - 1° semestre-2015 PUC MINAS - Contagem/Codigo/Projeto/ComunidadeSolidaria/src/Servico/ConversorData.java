/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servico;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Hebert
 */

public class ConversorData {

    public static String converterData(Date date) {
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        String data = sdf1.format(date);

        String[] aux = data.split("/");

        return aux[2] + "-" + aux[1] + "-" + aux[0];

    }
    public static String reverterData(Date date){
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        String data = sdf1.format(date);
        
        return data;    
    
    }
}
