/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servico;

import Dominio.Acesso;
import Dominio.Conta;
import Dominio.Endereco;
import Dominio.IAcesso;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author André Mendonça
 */
public class PersistenciaDeAcessos implements IAcesso{
    private final List<Acesso> listaDeAcessos;
    
    public PersistenciaDeAcessos(){
        this.listaDeAcessos = new ArrayList<>();
        Acesso temp = new Acesso();
        this.listaDeAcessos.add(temp);
    }
    
    @Override
    public List<Acesso> getListaDeAcessos(){
        return this.listaDeAcessos;
    }
    
    /**
     *
     * @param idAcesso
     * @param acesso
     */
    @Override
    public void persistirAcesso(int idAcesso, Acesso acesso){
        /// complementar função para persistir.
    }
}
