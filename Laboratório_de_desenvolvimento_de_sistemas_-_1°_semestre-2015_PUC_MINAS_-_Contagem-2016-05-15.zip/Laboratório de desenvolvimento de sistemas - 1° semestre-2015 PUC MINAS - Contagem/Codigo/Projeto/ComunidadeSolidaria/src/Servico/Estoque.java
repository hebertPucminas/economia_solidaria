/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servico;

/**
 *
 * @author André Mendonça
 */
public class Estoque {

    private int qtdeItem1 = 20;
    private int qtdeItem2 = 20;
    
    public boolean reservar(int idItem, int qtd){
        boolean reservaEfetuada = false;
        if(idItem == 1){
            if(this.qtdeItem1 >= qtd){
                this.qtdeItem1 -= qtd;
                reservaEfetuada = true;
            }
        }else if(idItem == 2){
            if(this.qtdeItem2 >= qtd){
                this.qtdeItem2 -= qtd;
                reservaEfetuada = true;
            }
        }
        return reservaEfetuada;
    }
}
