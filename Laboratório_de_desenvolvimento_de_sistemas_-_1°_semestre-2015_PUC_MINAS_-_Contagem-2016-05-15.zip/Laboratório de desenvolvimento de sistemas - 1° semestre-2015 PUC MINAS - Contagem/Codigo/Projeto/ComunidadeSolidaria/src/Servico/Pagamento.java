/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servico;

import Dominio.Conta;
import Dominio.IPagamento;

/**
 *
 * @author André Mendonça
 */
public class Pagamento implements IPagamento{

    public void efetuarTransacao(Conta conta, int n) {
        if (n == 2) {
            //pagamento atraves de cartão de credito
        } else if (n == 3) {
            // pagamento atraves de cartão de debito
        } else if (n == 4) {
            // pagamento atraves de boleto 
        }
    }
    
}
