/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servico;

import Dominio.Conta;
import Dominio.Endereco;
import Dominio.IConta;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author André Mendonça
 */
public class PersistenciaDeContas implements IConta{

    private final List<Conta> listaContas;

    public PersistenciaDeContas() {
        this.listaContas = new ArrayList<>();
        List<Endereco> enderecos = new ArrayList<>();
        Endereco e1 = new Endereco("Rua 1", "111", "Bairro Ines", "Contagem", "MG", "32013-000");
        Endereco e2 = new Endereco("Rua 2", "112", "Bairro Lincoln", "Contagem", "MG", "32013-200");
        enderecos.add(e1);
        enderecos.add(e2);
        Conta conta1 = new Conta("ABC", "123", enderecos);
        this.listaContas.add(conta1);
    }
    
    /**
     *
     * @param idCliente
     * @param password
     * @return
     */
    @Override
    public Conta getConta(String idCliente, String password) {
        Conta temp = null;
        for (Conta c : this.listaContas) {
            if (c.idCliente.equals(idCliente) && c.password.equals(password)) {
                temp = c;
            }
        }
        return temp;
    } 
}
