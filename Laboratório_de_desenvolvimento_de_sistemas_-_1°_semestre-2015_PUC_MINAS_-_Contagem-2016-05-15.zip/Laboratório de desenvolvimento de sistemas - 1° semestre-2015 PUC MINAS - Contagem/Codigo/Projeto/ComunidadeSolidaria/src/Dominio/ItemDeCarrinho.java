/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author André Mendonça
 */
public class ItemDeCarrinho {

    private DescricaoDeItem esp;
    private int qtd;

    public ItemDeCarrinho(DescricaoDeItem esp, int qtd) {
        this.esp = esp;
        this.qtd = qtd;
    }

    public double getPreco() {
        return esp.getPreco();
    }

    public double getSubtotal() {
        return this.esp.getPreco() * qtd;
    }

    public int getQtd() {
        return qtd;
    }

    public String getDescricao() {
        return this.esp.getDescricao();
    }
}
