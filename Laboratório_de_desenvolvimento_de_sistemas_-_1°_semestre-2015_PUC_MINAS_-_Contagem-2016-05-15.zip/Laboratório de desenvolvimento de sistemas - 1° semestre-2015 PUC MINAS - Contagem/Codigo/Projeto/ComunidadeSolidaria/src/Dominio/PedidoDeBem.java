/**
 * Aluno: Dellan Hoffman * Matrícula: 483763
 */
package dominio;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Hoffman
 */
public class PedidoDeBem {

    private int idPedidoDeBem;
    private int idLoja;
    private int idMembro;
    private double valor;
    private String enderecoEntrega;
    private Date dataPedido;
    private Date dataEntrega;
    private int status;

    public PedidoDeBem(int idPedidoDeBem, int idLoja, int idMembro, double valor, String enderecoEntrega, Date dataPedido, Date dataEntrega, int status) {
        this.idPedidoDeBem = idPedidoDeBem;
        this.idLoja = idLoja;
        this.idMembro = idMembro;
        this.valor = valor;
        this.enderecoEntrega = enderecoEntrega;
        this.dataPedido = dataPedido;
        this.dataEntrega = dataEntrega;
        this.status = status;
    }

    public int getIdLoja() {
        return idLoja;
    }

    public void setIdLoja(int idLoja) {
        this.idLoja = idLoja;
    }

    public int getIdMembro() {
        return idMembro;
    }

    public void setIdMembro(int idMembro) {
        this.idMembro = idMembro;
    }
    

  

    public PedidoDeBem() {
    }

   

    public int getIdPedidoDeBem() {
        return idPedidoDeBem;
    }

    public void setIdPedidoDeBem(int idPedidoDeBem) {
        this.idPedidoDeBem = idPedidoDeBem;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getEnderecoEntrega() {
        return enderecoEntrega;
    }

    public void setEnderecoEntrega(String enderecoEntrega) {
        this.enderecoEntrega = enderecoEntrega;
    }

    public Date getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(Date dataPedido) {
        this.dataPedido = dataPedido;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + this.idPedidoDeBem;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PedidoDeBem other = (PedidoDeBem) obj;
        if (this.idPedidoDeBem != other.idPedidoDeBem) {
            return false;
        }
        return true;
    }

}


