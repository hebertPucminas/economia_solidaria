/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author André Mendonça
 */
public class DescricaoDeItem {

    private int idItem;
    private String descricao;
    private double preco;

    public DescricaoDeItem(int idItem, String descricao, double preco) {
        this.idItem = idItem;
        this.descricao = descricao;
        this.preco = preco;
    }
    
    public int getIdItem(){
        return this.idItem;
    }
    
    public String getDescricao(){
        return this.descricao;
    }
    
    public double getPreco(){
        return this.preco;
    }
}
