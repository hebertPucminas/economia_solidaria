package Dominio;

import java.util.ArrayList;
import java.util.Random;

public class Acesso {

    //Lista de Acessos/Sessões habilitadas/existentes no sistema.

    private ArrayList<String> listaIdsAcessos;
    //Usado para gerar novo ID de Acesso
    private Random random = new Random();
    //Usado para receber o novo ID de Acesso vindo da classe Random
    private String IdAcesso;
    //Usado no loop para gerar novoIDAcesso
    private boolean controladora = false;

    public Acesso() {
        listaIdsAcessos = new ArrayList<>();
        
    }

    /**
     * Método para: Criar um novo Acesso quando for invocado Inserir o novo
     * Acesso na Lista de Acessos ativa e existente neste Sistema Retornar o
     * Acesso para quem invocou o método
     *
     * @param listaIdsAcessos = Lista de Acessos ativa e existente neste Sistema
     * @return = Retorna um novo Acesso no formato String de tamanaho maior ou
     * igual a 15 caracteres
     */
    public String criarIDAcessoSistema(ArrayList<String> listaIdsAcessos) {
        //Recebe a Lista de Acessos deste Sistema
        this.listaIdsAcessos = listaIdsAcessos;

        /*Irá efetuar este LOOP até encontrar um novo Acesso maior ou igual a 15
         e que não exista ainda na Lista de Acessos deste Sistema
         */
        do {
            //Cria um novo Acesso Aleatório e Seta ele em Acesso
            this.IdAcesso = String.valueOf(random.nextLong());

            //Para aumentar a segurança só permite continuar a inserção se Acesso for maior ou igual a 15
            if (this.IdAcesso.length() >= 15) {
                //Verifica se o Acesso já existe na Lista de Acessos deste Sistema para não permitir inserções de IdAcessos iguais
                if (!this.listaIdsAcessos.contains(IdAcesso)) {
                    //Adiciona o Acesso na Lista de Acessos deste Sistema
                    listaIdsAcessos.add(IdAcesso);
                    //Seta True para parar o Loop
                    controladora = true;
                }
            }
        } while (controladora == false);

        //Retorna o Acesso para quem invocou o método
        return this.IdAcesso;
    }

    /**
     * Método para: Verificar se o Acesso informado já existe ou está ativo
     * neste Sistema
     *
     * @param IdAcesso = Acesso que deseja verificar se existe neste Sistema
     * @param listaIdsAcessos = Lista de IdAcessos existente neste Sistema
     * @return = True se o Acesso existir e False se ele não existir
     */
    public boolean verificarIDAcessoSistema(String IdAcesso, ArrayList<String> listaIdsAcessos) {
        if (listaIdsAcessos.contains(IdAcesso)) {
            return true;
        } else {
            return false;
        }
    }

    public ArrayList<String> getListaIdsAcessos() {
        return listaIdsAcessos;
    }

    public String getIdAcesso() {
        return IdAcesso;
    }

}
