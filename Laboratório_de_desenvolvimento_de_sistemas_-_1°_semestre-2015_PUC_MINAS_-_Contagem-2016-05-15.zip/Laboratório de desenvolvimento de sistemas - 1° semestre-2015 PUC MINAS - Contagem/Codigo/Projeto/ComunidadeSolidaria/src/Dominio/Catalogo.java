/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author André Mendonça
 */
public class Catalogo {

    private List<DescricaoDeItem> items;

    public Catalogo() {
        items = new ArrayList<>();
        atualizar();
    }

    public void atualizar() {
        if (!items.isEmpty()) {
            items.clear();
        }
        
        List<DescricaoDeItem> lista = new ArrayList<>();

        try {
            lista = new DAO.DaoBem().preencherCatalogo();
            for (DescricaoDeItem esp : lista) {
                items.add(esp);
            }
            System.out.println("Catalogo atualizado");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Catalogo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Catalogo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public DescricaoDeItem obter(int idItem) {
        DescricaoDeItem temp = null;
        for (DescricaoDeItem d : this.items) {

            if (d.getIdItem() == idItem) {
                return d;

            }
        }
        return temp;
    }

    public List<DescricaoDeItem> getItens() {
        return items;
    }
}
