/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author André Mendonça
 */
public class Consumidor {

    private int idConsumidor;
    private Carrinho carrinho;

    public Consumidor() {
        this.carrinho = new Carrinho();
    }

    public void adicionar(DescricaoDeItem esp, int qtd) {
        this.carrinho.adicionar(esp, qtd);
    }

    public Carrinho getCarrinho() {
        return carrinho;
    }

    public double apurarTotal() {
        return this.carrinho.apurarTotal();
    }   
    
    

    public void desistirDaCompra() {
        carrinho.desistirDaCompra();
    }

    public int getIdConsumidor() {
        return idConsumidor;
    }

    public void setIdConsumidor(int idConsumidor) {
        this.idConsumidor = idConsumidor;
    }

}
