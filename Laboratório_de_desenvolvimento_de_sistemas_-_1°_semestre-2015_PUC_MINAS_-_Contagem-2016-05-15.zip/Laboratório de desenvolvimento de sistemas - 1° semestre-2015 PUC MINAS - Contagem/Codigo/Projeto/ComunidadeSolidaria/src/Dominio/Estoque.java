/**
 * Aluno: Dellan Hoffman * Matrícula: 483763
 */
package Dominio;

/**
 *
 * @author Hoffman
 */
public class Estoque {

    private int idEstoque;
    private String descricao;
    private int idLoja;
    private int idBem;
    private int qtd;
    private int status;

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Estoque(int idEstoque, String descricao, int idLoja, int idBem, int qtd, int status) {
        this.idEstoque = idEstoque;
        this.descricao = descricao;
        this.idLoja = idLoja;
        this.idBem = idBem;
        this.qtd = qtd;
        this.status = status;
    }

    public Estoque(int idEstoque, String descricao, int idLoja, int idBem) {
        this.idEstoque = idEstoque;
        this.descricao = descricao;
        this.idLoja = idLoja;
        this.idBem = idBem;
    }

    public Estoque() {
    }



    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + this.idEstoque;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Estoque other = (Estoque) obj;
        if (this.idEstoque != other.idEstoque) {
            return false;
        }
        return true;
    }

    public int getIdEstoque() {
        return idEstoque;
    }

    public void setIdEstoque(int idEstoque) {
        this.idEstoque = idEstoque;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getIdLoja() {
        return idLoja;
    }

    public void setIdLoja(int idLoja) {
        this.idLoja = idLoja;
    }

    public int getIdBem() {
        return idBem;
    }

    public void setIdBem(int idBem) {
        this.idBem = idBem;
    }

}
