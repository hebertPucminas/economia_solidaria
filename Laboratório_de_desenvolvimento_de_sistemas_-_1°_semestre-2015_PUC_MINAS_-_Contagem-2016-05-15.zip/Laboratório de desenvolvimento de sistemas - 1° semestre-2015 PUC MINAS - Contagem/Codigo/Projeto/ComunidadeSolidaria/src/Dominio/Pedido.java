/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Klinger
 */
public class Pedido {

    private int idPedido;
    private int idLoja;//vendedor
    private int idMembro;//comprador
    private String situacao; //Estado do pedido
    private String enderecoEntrega;
    private List<ItemDeCarrinho> itensDoCarrinho;
    private Double valor;
    private String codigoTransportadora;
    private Date dataPedido;
    private Date dataEntrega;

    public Pedido() {
        this.dataPedido = new Date();
    }

    public Date getDataPedido() {
        return dataPedido;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public String getEnderecoEntrega() {
        return enderecoEntrega;
    }

    public void setEnderecoEntrega(String enderecoEntrega) {
        this.enderecoEntrega = enderecoEntrega;
    }

    public List getItensDoCarrinho() {
        return itensDoCarrinho;
    }

    public void setItensDoCarrinho(List itensDoCarrinho) {
        this.itensDoCarrinho = itensDoCarrinho;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getCodigoTransportadora() {
        return codigoTransportadora;
    }

    public void setCodigoTransportadora(String codigoTransportadora) {
        this.codigoTransportadora = codigoTransportadora;
    }

    public int getIdLoja() {
        return idLoja;
    }

    public void setIdLoja(int idLoja) {
        this.idLoja = idLoja;
    }

    public int getIdMembro() {
        return idMembro;
    }

    public void setIdMembro(int idMembro) {
        this.idMembro = idMembro;
    }

    //verificar a possibilidade de receber idMembro e idLoja no construtor
    public void criar(Endereco endereco, Carrinho carrinho, int idConsumidor, int idProdutor) {
        this.itensDoCarrinho = carrinho.getItemCar();
        this.enderecoEntrega = endereco.getLogradouro() + ", "
                + endereco.getNumero() + ", "
                + endereco.getBairro() + ", "
                + endereco.getCidade() + ", "
                + endereco.getEstado() + ", "
                + endereco.getCep() + ".";
        String items = "";

        idMembro = idConsumidor;
        idLoja = idProdutor;

        for (ItemDeCarrinho ic : itensDoCarrinho) {
            items += ic.getDescricao() + "   " + ic.getPreco() + "   " + ic.getSubtotal() + "\n";
        }

        items += "\nValor total:R$" + carrinho.apurarTotal();
        this.valor = carrinho.apurarTotal();
        this.situacao = "INICIADO";

        String x = "30/06/2015";
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");

        try {
            dataEntrega = sdf1.parse(x);

        } catch (ParseException ex) {
            Logger.getLogger(Pedido.class.getName()).log(Level.SEVERE, null, ex);
        }

        JOptionPane.showMessageDialog(null, "Código cliente:" + idConsumidor + "\nCódigo do Produtor:" + idProdutor + "\n" + items + "\nData do Pedido:" + Servico.ConversorData.reverterData(dataPedido) + "\nData de Entrega:" + Servico.ConversorData.reverterData(dataEntrega));
        new DAO.DaoPedido().salvarPedidoBem(this);
        idPedido = new DAO.DaoPedido().retornarID_UltimoPedido();

        for (ItemDeCarrinho item : itensDoCarrinho) {
            new DAO.DaoPedido().salvarItensDePedido(item, idPedido);
        }

    }

//=============== METODOS PARA CONTROLE DO ESTADO DO PEDIDO ===============
    public void isPago() {
        this.situacao = "PAGO";
    }

    public void isEnviado() {
        this.situacao = "ENVIADO PARA TRANSPORTE";
    }

    public void isEntregue() {
        this.situacao = "ENTREGUE";
    }

    public void isDevolvido() {
        this.situacao = "DEVOLVIDO";
    }

    public void isFinalizado() {
        this.situacao = "FINALIZADO";
    }
}
