/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import DAO.*;
import Servico.Estoque;
import Servico.PersistenciaDeAcessos;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author André Mendonça
 */
public class Comunidade {

    private final Catalogo catalogo = new Catalogo();
    private Endereco ende;
    private Acesso acessoCorrente;
    private Consumidor consumidorCorrente;

    public Comunidade() {
        acessoCorrente = new Acesso();
        criarAcesso();

    }

    public Acesso getAcessoCorrente() {
        return acessoCorrente;
    }

    public void login() {
        // fazer login
        int idConsumidor = 2;// Recebe o id do login , default 0
        consumidorCorrente.setIdConsumidor(idConsumidor);
    }

    public Catalogo getCatalogo() {
        return catalogo;
    }

    public Consumidor getConsumidorCorrente() {
        return this.consumidorCorrente;
    }

    public boolean adicionarCompra(int id_Item, String NomeProduto, int qtd) {
        DescricaoDeItem descricao = new Catalogo().obter(id_Item);
        new Estoque().reservar(id_Item, qtd);
        consumidorCorrente.adicionar(descricao, qtd);

        return true;
    }

    public void criarAcesso() {
        acessoCorrente.criarIDAcessoSistema(acessoCorrente.getListaIdsAcessos());
        this.consumidorCorrente = new Consumidor();

    }

    public double obterTotal() {

        return consumidorCorrente.getCarrinho().apurarTotal();
    }

    public void inserirBem(Bem bem) {
        try {
            new DaoBem().salvar(bem);
        } catch (Exception e) {
            System.err.println(e);
        }

    }

    public void deletarBem(Bem bem) {
        // verificar login

        try {
            new DaoBem().deletar(bem);
            catalogo.atualizar();

        } catch (Exception e) {
            System.err.println(e);
        }

    }

    public void finalizar(int idConsumidor, int idProdutor) {
        definirEndereco(null, null, null, null, null, null);
        consumidorCorrente.getCarrinho().esvaziarCarrinho(ende, idConsumidor, idProdutor);

    }

    public void definirEndereco(String logradouro, String numero, String bairro, String cidade, String estado, String cep) {
        ende = new Endereco("Teste", "123", "123", "123", "123", "123");
//        this.acessoCorrente.definirEndereco(temp);
    }

    public boolean efetuarPagamento(int tipodepagamento) {
        boolean status = false;
        //  this.acessoCorrente.pagar(tipodepagamento);
        status = true;

        return status;
    }

    public List<Object[]> pesquisar(String nome, int idProdutor) {

        int aux = 0;
        List<Object[]> lista;

        if (idProdutor == 0) {

            try {
                lista = new DaoBem().pesquisarNome(nome);

                return lista;
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Comunidade.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Comunidade.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                lista = new DaoBem().buscarListaID_Produtor(nome, idProdutor);

                return lista;
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Comunidade.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Comunidade.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        return null;

    }

    public void desistirDaCompra() {
        consumidorCorrente.getCarrinho().limparCarrinho();
    }

}
