/**
 * Aluno: Dellan Hoffman * Matrícula: 483763
 */
package Dominio;

/**
 *
 * @author Hoffman
 */
public class Bem {

    private int idBem;
    private String nome;
    private String descricao;
    private String marca;
    private double preco;
    private int categoria;
    private String urlImagem;

    private String enderecoFisico;
    private String enderecoVirtual;
    private Loja loja;
    private int situacao;
    private int idLoja;

    public Bem() {
    }

    public Bem(int idBem, String nome, String descricao, String marca, double preco, int categoria, String urlImagem, String enderecoFisico, String enderecoVirtual, int idloja, int situacao) {
        this.idBem = idBem;
        this.nome = nome;
        this.descricao = descricao;
        this.marca = marca;
        this.preco = preco;
        this.categoria = categoria;
        this.urlImagem = urlImagem;
        this.enderecoFisico = enderecoFisico;
        this.enderecoVirtual = enderecoVirtual;
        //this.loja = loja;
        this.idLoja = idloja;
        this.situacao = situacao;
    }

    public int getIdBem() {
        return idBem;
    }

    public void setIdBem(int idBem) {
        this.idBem = idBem;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public String getUrlImagem() {
        return urlImagem;
    }

    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }

    public String getEnderecoFisico() {
        return enderecoFisico;
    }

    public void setEnderecoFisico(String enderecoFisico) {
        this.enderecoFisico = enderecoFisico;
    }

    public String getEnderecoVirtual() {
        return enderecoVirtual;
    }

    public void setEnderecoVirtual(String enderecoVirtual) {
        this.enderecoVirtual = enderecoVirtual;
    }

    public Loja getLoja() {
        return loja;
    }

    public void setLoja(Loja loja) {
        this.loja = loja;
    }

    public int getSituacao() {
        return situacao;
    }

    public void setSituacao(int situacao) {
        this.situacao = situacao;
    }

    @Override
    public String toString() {
        return "Bem{" + "idBem=" + idBem + ", nome=" + nome + ", descricao=" + descricao + ", marca=" + marca + ", preco=" + preco + ", categoria=" + categoria + ", urlImagem=" + urlImagem + ", enderecoFisico=" + enderecoFisico + ", enderecoVirtual=" + enderecoVirtual + ", loja=" + loja + ", situacao=" + situacao + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.idBem;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Bem other = (Bem) obj;
        if (this.idBem != other.idBem) {
            return false;
        }
        return true;
    }

    public int getIdLoja() {
        return idLoja;
    }

    public void setIdLoja(int idLoja) {
        this.idLoja = idLoja;
    }

}
