/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author André Mendonça
 */
public class Carrinho {

    public double total;
    private ItemDeCarrinho item;
    private List<ItemDeCarrinho> itensDeCarrinho;

    public Carrinho() {
        this.itensDeCarrinho = new ArrayList<>();
    }

    public void adicionar(DescricaoDeItem esp, int qtd) {
        this.item = new ItemDeCarrinho(esp, qtd);
        String m = "Adicionado novo item:\nQtd.: " + qtd
                + " - " + item.getDescricao() + ", Valor: " + item.getSubtotal() + " R$.";
        JOptionPane.showMessageDialog(null, m, "Carrinho", 1);
        this.itensDeCarrinho.add(item);
        JOptionPane.showMessageDialog(null, "Adicionou no carrinho!");
    }

    public double apurarTotal() {
        this.total = 0;
        for (ItemDeCarrinho d : getItemCar()) {
            this.total += d.getSubtotal();
        }
        return this.total;
    }

    public ItemDeCarrinho getItem() {
        return item;
    }

    public void esvaziarCarrinho(Endereco endereco, int idConsumidor, int idProdutor) {
        if (apurarTotal() > 0) {
            Pedido pedido = new Pedido();
            pedido.criar(endereco, this, idConsumidor, idProdutor);
            this.getItemCar().clear();
        }else{
            JOptionPane.showMessageDialog(null, "Compra não finalizada, carrinho Vazio");
        }
    }

    public void limparCarrinho() {
        this.itensDeCarrinho.clear();
    }

    /**
     * @return the itensDeCarrinho
     */
    public List<ItemDeCarrinho> getItemCar() {
        return itensDeCarrinho;
    }

    public void desistirDaCompra() {
        this.itensDeCarrinho.clear();
    }

}
