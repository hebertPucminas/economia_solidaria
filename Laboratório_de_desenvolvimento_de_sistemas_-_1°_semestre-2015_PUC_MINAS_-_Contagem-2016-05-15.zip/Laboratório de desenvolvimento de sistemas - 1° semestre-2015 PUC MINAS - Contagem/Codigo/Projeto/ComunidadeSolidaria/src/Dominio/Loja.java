/**
 * Aluno: Dellan Hoffman * Matrícula: 483763
 */

package Dominio;

/**
 *
 * @author Hoffman
 */
public class Loja {
private int idLoja;
private String descricao;
private int idMembro;

    public Loja() {
    }

    public Loja(int idLoja, String descricao, int idMembro) {
        this.idLoja = idLoja;
        this.descricao = descricao;
        this.idMembro = idMembro;
    }

    public int getIdLoja() {
        return idLoja;
    }

    public void setIdLoja(int idLoja) {
        this.idLoja = idLoja;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getIdMembro() {
        return idMembro;
    }

    public void setIdMembro(int idMembro) {
        this.idMembro = idMembro;
    }

    @Override
    public String toString() {
        return "Loja{" + "Descricao: " + descricao + '}';
    }

}
