/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.List;

/**
 *
 * @author André Mendonça
 */
public interface IAcesso {
    public List<Acesso> getListaDeAcessos();   
    public void persistirAcesso(int idAcesso, Acesso acesso);
}
