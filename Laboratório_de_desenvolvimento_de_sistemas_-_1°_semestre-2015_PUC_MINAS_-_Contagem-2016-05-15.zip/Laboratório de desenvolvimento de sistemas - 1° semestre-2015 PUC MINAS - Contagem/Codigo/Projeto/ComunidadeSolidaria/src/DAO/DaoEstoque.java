/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Dominio.Estoque;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Hoffman
 */
public class DaoEstoque implements Dao.IDao<Estoque> {

    // a conexão com o banco de dados
    private Connection connection;
    private Object oLista;

    public DaoEstoque() throws ClassNotFoundException, SQLException {
        this.connection = DAO.Conexao.getInstancia().getConnection();
    }

    /**
     *
     * @param estoque
     * @throws Exception
     */
    @Override
    public void salvar(Estoque estoque) throws Exception {
        int idestoque = estoque.getIdEstoque();
        String sql = (" insert into estoque(Descricao=?, Loja_idLoja, idBem, Qtd, Status) Values(?, ?, ?, ?, ?) ");

        if (idestoque > 0) {
            sql = (" update estoque set Loja_idLoja=?, idBem=?, Qtd=?, Status=? where idEstoque =  ?");

        }
        try {
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {

                stmt.setString(1, estoque.getDescricao());
                stmt.setInt(2, estoque.getIdLoja());
                stmt.setInt(3, estoque.getIdBem());
                stmt.setInt(4, estoque.getQtd());
                stmt.setInt(5, estoque.getStatus());

                if (idestoque > 0) {
                    stmt.setInt(6, idestoque);
                }

                stmt.execute();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deletar(Estoque estoque) throws Exception {
        int idestoque = estoque.getIdEstoque();
        String sql = (" delete from estoque  where idEstoque = ? ");

        try {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {

                ps.setInt(1, idestoque);

                ps.execute();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    /*
     public ResultSet buscarPorID(int Id) throws Exception {
    
     String sql = (" select idEstoque, idMembro, login, senha, email From estoque  where idEstoque = ? ");
    
     try {
     try (PreparedStatement ps = connection.prepareStatement(sql)) {
    
     ps.setInt(1, Id);
     ResultSet result = ps.executeQuery();
     Estoque oEstoque = new Estoque(result.getInt(1), result.getInt(2), result.getString(3), result.getString(4), result.getString(5));
     return result;
     }
     } catch (SQLException e) {
     throw new RuntimeException(e);
     }
     }*/

    
  

    @Override
    public Estoque buscarPorID(int Id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Estoque> buscarTodos() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

}
