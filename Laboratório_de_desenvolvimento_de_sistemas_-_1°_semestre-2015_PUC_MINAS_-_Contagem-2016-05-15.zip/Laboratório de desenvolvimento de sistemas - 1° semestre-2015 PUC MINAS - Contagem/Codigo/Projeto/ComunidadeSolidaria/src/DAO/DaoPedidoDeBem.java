/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import dominio.PedidoDeBem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hoffman
 */
public class DaoPedidoDeBem implements IDaoResult<PedidoDeBem> {

    // a conexão com o banco de dados
    private Connection connection;
    private Object oLista;

    public DaoPedidoDeBem() throws ClassNotFoundException, SQLException {
        this.connection = Conexao.getConexao();
    }

    /**
     *
     * @param pedidoDeBem
     * @throws Exception
     */
    @Override
    public void salvar(PedidoDeBem pedidoDeBem) throws Exception {
        int idpedidoDeBem = pedidoDeBem.getIdPedidoDeBem();
        String sql = (" insert into pedidoDeBem(idLoja, idMembro, Valor, EnderecoEntrega, DataPedido"
                + ", DataEntrega, Status) Values(?, ?, ?, ?, ?, ?, ?) ");

        if (idpedidoDeBem > 0) {
            sql = (" update pedidoDeBem set "
                    + "idLoja=?, idMembro=?, Valor=?, EnderecoEntrega=?, DataPedido=?"
                    + ", DataEntrega=?, Status=?"
                    + " where idPedidoDeBem =  ?");

        }
        try {
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {

                stmt.setInt(1, pedidoDeBem.getIdLoja());
                stmt.setInt(2, pedidoDeBem.getIdMembro());
                stmt.setDouble(3, pedidoDeBem.getValor());
                stmt.setString(4, pedidoDeBem.getEnderecoEntrega());
                stmt.setDate(5, (java.sql.Date) new Date(pedidoDeBem.getDataPedido().getTime()));
                stmt.setDate(6, (java.sql.Date) new Date(pedidoDeBem.getDataEntrega().getTime()));
                stmt.setInt(7, pedidoDeBem.getStatus());

                if (idpedidoDeBem > 0) {
                    stmt.setInt(8, idpedidoDeBem);
                }

                stmt.execute();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deletar(PedidoDeBem pedidoDeBem) throws Exception {
        int idpedidoDeBem = pedidoDeBem.getIdPedidoDeBem();
        String sql = (" delete from pedidoDeBem  where idPedidoDeBem = ? ");

        try {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {

                ps.setInt(1, idpedidoDeBem);

                ps.execute();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    /*
     public ResultSet buscarPorID(int Id) throws Exception {
    
     String sql = (" select idPedidoDeBem, idMembro, login, senha, email From pedidoDeBem  where idPedidoDeBem = ? ");
    
     try {
     try (PreparedStatement ps = connection.prepareStatement(sql)) {
    
     ps.setInt(1, Id);
     ResultSet result = ps.executeQuery();
     PedidoDeBem oPedidoDeBem = new PedidoDeBem(result.getInt(1), result.getInt(2), result.getString(3), result.getString(4), result.getString(5));
     return result;
     }
     } catch (SQLException e) {
     throw new RuntimeException(e);
     }
     }*/

    @Override
    public ResultSet buscarTodos() throws Exception {
        // List<PedidoDeBem> oLista = new ArrayList<>();

        String sql = (" select * From pedidoDeBem ");

        try {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {

                ResultSet result = ps.executeQuery();
                /*while (result.next()) {
                 PedidoDeBem oPedidoDeBem = new PedidoDeBem(result.getInt(1), result.getInt(2), result.getString(3), result.getString(4), result.getString(5));
                 oLista.add(oPedidoDeBem);
                 }*/
                return result;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Object[]> pesquisar(String nome) {
        List<Object[]> lista = new ArrayList<>();
        String query = "select * from estoque \n"
                + "where Descricao like '"+nome+"%'";

        try {
            ResultSet rs = connection.createStatement().executeQuery(nome);

            while (rs.next()) {
                lista.add(new Object[]{rs.getInt("idEstoque"), rs.getString("descricao"), rs.getInt("loja_idloja"),rs.getInt("idBem"),rs.getInt("Qtd"), rs.getInt("Status")});
                
            }

        } catch (SQLException ex) {
            Logger.getLogger(DaoPedidoDeBem.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
}
