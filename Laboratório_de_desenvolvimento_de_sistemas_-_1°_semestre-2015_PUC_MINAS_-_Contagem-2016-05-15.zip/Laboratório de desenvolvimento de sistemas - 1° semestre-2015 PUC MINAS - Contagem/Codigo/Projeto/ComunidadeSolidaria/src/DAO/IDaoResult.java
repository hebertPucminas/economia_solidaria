package Dao;

import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author Hoffman
 * @param <T>
 */
public interface IDaoResult<T> {

    void salvar(T e) throws Exception;

    void deletar(T e) throws Exception;

    ResultSet buscarTodos() throws Exception;
}
