/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Dominio.ItemDeCarrinho;
import Dominio.Pedido;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Hebert
 */
public class DaoPedido {

    public void salvarPedidoBem(Pedido pedido) {
        // transformar pedido
        String insert = "insert into pedidodebem (idLoja, idMembro, Valor, EnderecoEntrega, DataPedido, DataEntrega, Situacao)\n"
                + "values (" + pedido.getIdLoja() + ", " + pedido.getIdMembro() + " , " + pedido.getValor() + " , '" + pedido.getEnderecoEntrega() + "', '" + Servico.ConversorData.converterData(pedido.getDataPedido()) + "', '" + Servico.ConversorData.converterData(pedido.getDataEntrega()) + "', '" + pedido.getSituacao() + "')";
        System.out.println("\n" + insert);

        try {
            Conexao.getInstancia().stmt.execute(insert);
            JOptionPane.showMessageDialog(null, "Pedido registrado com sucesso");
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao registrar pedido");
        }

    }

    public int retornarID_UltimoPedido() {
        String query = "select idPedidoDeBem from pedidodebem\n"
                + "order by idPedidoDeBem desc limit 0,1";

        System.out.println(query);

        int valorId = 0;
        try {
            ResultSet rs = Conexao.getInstancia().stmt.executeQuery(query);

            while (rs.next()) {
                valorId = rs.getInt("idPedidoDeBem");
            }

        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }

        return valorId;
    }

    public void salvarItensDePedido(ItemDeCarrinho item, int idPedido) {
        String update = "insert into itempedido (idPedido, DescricaoItem, QtdItem, TipoItem, Valor)\n"
                + "values (" + idPedido + ", '" + item.getDescricao() + "', " + item.getQtd() + ", 0 , " + item.getPreco() + ") ";

        System.out.println(update);
        
        try {
            Conexao.getInstancia().stmt.executeUpdate(update);
            System.out.println("Item de pedido Salvo");
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

}
