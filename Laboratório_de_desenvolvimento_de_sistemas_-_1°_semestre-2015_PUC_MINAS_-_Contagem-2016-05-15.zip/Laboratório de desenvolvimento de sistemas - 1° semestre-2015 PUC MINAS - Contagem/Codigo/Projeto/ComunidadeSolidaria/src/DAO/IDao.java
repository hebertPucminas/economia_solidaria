/**
 * Aluno: Dellan Hoffman * Matrícula: 483763
 */
package Dao;

import java.util.List;

/**
 *
 * @author Hoffman
 * @param <T>
 */
public interface IDao<T> {

    void salvar(T e) throws Exception;

    void deletar(T e) throws Exception;

    T buscarPorID(int Id) throws Exception;

    List<T> buscarTodos() throws Exception;
}
