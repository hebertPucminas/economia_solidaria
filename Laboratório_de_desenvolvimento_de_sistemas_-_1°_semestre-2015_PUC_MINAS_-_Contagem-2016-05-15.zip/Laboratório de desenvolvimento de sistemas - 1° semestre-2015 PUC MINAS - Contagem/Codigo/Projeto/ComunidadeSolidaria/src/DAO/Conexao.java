package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
/*
 Classe Conexão com o Singleton Pattern
 */

public final class Conexao {

    private final String driver = "com.mysql.jdbc.Driver";
    private Connection con;
    public Statement stmt;
    public ResultSet resul;
    private static volatile Conexao instancia;
    public static final String DATABASE = "db_sissolidario";

    private Conexao() {

    }

    public static Conexao getInstancia() {
        if (Conexao.instancia == null) {
            synchronized (Conexao.class) {
                if (Conexao.instancia == null) {
                    Conexao.instancia = new Conexao();
                }
            }
        }
        return Conexao.instancia;
    }

    public void Conectar() {

        try {
            Class.forName(driver);
            con = (Connection) java.sql.DriverManager.getConnection("jdbc:mysql://localhost/" + this.DATABASE + "", "root", "");
            stmt = (Statement) con.createStatement();
            System.out.println("Conectado");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao conectar, abrir programa Xampp e conectar");
            throw new java.lang.RuntimeException("Erro ao conectar");
        }
    }

    public Connection getConnection() {
        return con;

    }

    public void Desconectar() throws SQLException {
        try {
            con.close();
            stmt.close();
        } catch (Exception e) {
            throw new java.lang.RuntimeException("Erro ao fechar");
        }
    }

}
