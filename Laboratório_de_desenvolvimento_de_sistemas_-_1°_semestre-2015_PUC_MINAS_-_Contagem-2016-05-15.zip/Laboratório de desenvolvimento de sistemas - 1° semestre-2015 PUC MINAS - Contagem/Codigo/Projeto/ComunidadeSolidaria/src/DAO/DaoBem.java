/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DAO.Conexao;
import Dao.IDao;
import Dominio.Bem;
import Dominio.DescricaoDeItem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hoffman
 */
public class DaoBem implements IDao<Bem> {

    // a conexão com o banco de dados
    private Connection connection;
    private ResultSet rs;

    public DaoBem() throws ClassNotFoundException, SQLException {
        this.connection = Conexao.getInstancia().getConnection();
    }

    /**
     *
     * @param bem
     * @throws Exception
     */
    @Override
    public void salvar(Bem bem) throws Exception {
        int idbem = bem.getIdBem();
        int idLoja = bem.getIdLoja();

        String sql = (" insert into bem(nome, descricaoDeBem, marca, preco, categoria,"
                + " urlImagem, EnderecoFisico, EnderecoDigital, idLoja, Situacao) "
                + "Values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

        if (idbem > 0) {
            sql = (" update bem set nome=?, descricaoDeBem=?, marca=?, preco=?, categoria=?, "
                    + " urlImagem=?, EnderecoFisico=?, EnderecoDigital=?, idLoja=?, Situacao=?"
                    + " where idBem = ?");

        }
        try {
            System.out.println(sql);
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {

                stmt.setString(1, bem.getNome());
                stmt.setString(2, bem.getDescricao());
                stmt.setString(3, bem.getMarca());
                stmt.setDouble(4, bem.getPreco());
                stmt.setInt(5, bem.getCategoria());
                stmt.setString(6, bem.getUrlImagem());
                stmt.setString(7, bem.getEnderecoFisico());
                stmt.setString(8, bem.getEnderecoVirtual());
                stmt.setInt(9, idLoja);
                stmt.setInt(10, bem.getSituacao());

                if (idbem > 0) {
                    stmt.setInt(11, idbem);
                }

                stmt.execute();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deletar(Bem bem) throws Exception {
        int idbem = bem.getIdBem();
        String sql = (" delete from bem  where idBem = ? ");

        try {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {

                ps.setInt(1, idbem);

                ps.execute();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Bem buscarPorID(int Id) throws Exception {

        String sql = (" select nome, descricaoDeBem, marca, preco, categoria"
                + "urlImagem, EnderecoFisico, EnderecoDigital, idLoja, Situacao  where idBem = ? ");

        try {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {

                ps.setInt(1, Id);
                ResultSet result = ps.executeQuery();
                Bem oBem = new Bem(result.getInt(1),
                        result.getString(2),
                        result.getString(3),
                        result.getString(4),
                        result.getDouble(5),
                        result.getInt(6),
                        result.getString(7),
                        result.getString(8),
                        result.getString(9),
                        result.getInt(10),
                        result.getInt(11));

                return oBem;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Object[]> pesquisarNome(String nome) {
        List<Object[]> lista = new ArrayList<>();
        String query = "select * from bem "
                + "where nome like '" + nome + "%' ; ";

        try {
            rs = Conexao.getInstancia().stmt.executeQuery(query);

            while (rs.next()) {

                lista.add(new Object[]{rs.getInt("idBem"), rs.getString("nome"), rs.getString("DescricaoDeBem"), rs.getString("marca"), rs.getDouble("preco"), rs.getInt("idLoja")});
            }

        } catch (SQLException ex) {
            Logger.getLogger(DaoBem.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }

    public List<Object[]> buscarListaID_Produtor(String nome, int idProdutor) {
        List<Object[]> lista = new ArrayList<>();
        String query = "select * from bem "
                + "where nome like '" + nome + "%' and idLoja = " + idProdutor + " ; ";

        try {
            rs = Conexao.getInstancia().stmt.executeQuery(query);

            while (rs.next()) {

                lista.add(new Object[]{rs.getInt("idBem"), rs.getString("nome"), rs.getString("DescricaoDeBem"), rs.getString("marca"), rs.getDouble("preco"), rs.getInt("idLoja")});
            }

        } catch (SQLException ex) {
            Logger.getLogger(DaoBem.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;

    }

    public List<DescricaoDeItem> preencherCatalogo() {
        List<DescricaoDeItem> lista = new ArrayList<>();
        String query = "select * from bem ";

        try {
            rs = Conexao.getInstancia().stmt.executeQuery(query);

            while (rs.next()) {
                lista.add(new DescricaoDeItem(rs.getInt("idBem"), rs.getString("descricaoDeBem"), rs.getDouble("preco")));
            }

        } catch (SQLException ex) {
            Logger.getLogger(DaoBem.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }

    @Override
    public List<Bem> buscarTodos() throws Exception {
        List<Bem> oLista = new ArrayList<>();

        String sql = (" select nome, descricaoDeBem, marca, preco, categoria"
                + "urlImagem, CodProdutor, EnderecoFisico, EnderecoDigital, idLoja, Situacao"
                + " From bem ");

        try {
            try (PreparedStatement ps = connection.prepareStatement(sql)) {

                ResultSet result = ps.executeQuery();
                while (result.next()) {
                    Bem oBem = new Bem(result.getInt(1),
                            result.getString(2),
                            result.getString(3),
                            result.getString(4),
                            result.getDouble(5),
                            result.getInt(6),
                            result.getString(7),
                            result.getString(8),
                            result.getString(9),
                            result.getInt(10),
                            result.getInt(11));
                    oLista.add(oBem);
                }
                return oLista;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
