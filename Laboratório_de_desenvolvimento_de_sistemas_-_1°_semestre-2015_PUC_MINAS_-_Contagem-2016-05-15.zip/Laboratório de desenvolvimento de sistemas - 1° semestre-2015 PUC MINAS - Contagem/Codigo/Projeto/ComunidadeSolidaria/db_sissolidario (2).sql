-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 13-Jun-2015 às 01:41
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_sissolidario`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agenda`
--

CREATE TABLE IF NOT EXISTS `agenda` (
  `idAgenda` int(11) NOT NULL,
  `idLoja` int(11) DEFAULT NULL,
  `idItemPedidoDeServico` int(11) DEFAULT NULL,
  `Descricao` varchar(45) DEFAULT NULL,
  `Data` date DEFAULT NULL,
  `Hora` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `bem`
--

CREATE TABLE IF NOT EXISTS `bem` (
`idBem` int(10) unsigned NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `DescricaoDeBem` varchar(45) DEFAULT NULL,
  `Marca` varchar(45) DEFAULT NULL,
  `Preco` decimal(18,2) NOT NULL,
  `Categoria` int(11) DEFAULT NULL,
  `UrlImagem` varchar(200) DEFAULT NULL,
  `EnderecoFisico` varchar(100) DEFAULT NULL,
  `EnderecoDigital` varchar(200) DEFAULT NULL,
  `idLoja` int(11) DEFAULT NULL,
  `Situacao` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `bem`
--

INSERT INTO `bem` (`idBem`, `Nome`, `DescricaoDeBem`, `Marca`, `Preco`, `Categoria`, `UrlImagem`, `EnderecoFisico`, `EnderecoDigital`, `idLoja`, `Situacao`) VALUES
(1, 'Sabonete', 'pacote sabonete 6 unidades', 'Lux', '1.50', 1, NULL, NULL, NULL, 1, '1'),
(2, 'Sabão em pó', 'Sabão em pó', 'OMO', '3.00', 1, NULL, NULL, NULL, 1, '1'),
(3, 'Detergente', 'Detergente Líquido', 'Ipê', '4.20', 1, NULL, NULL, NULL, 1, '1'),
(4, 'Sabonete', 'Sabonete Luxuoso', 'Lux', '3.00', 1, NULL, NULL, NULL, 1, '0'),
(5, 'Salgados', '100 salgados sortidos', 'sem marca', '60.00', 2, NULL, NULL, NULL, 1, '0'),
(6, 'Salgados', '50 salgados sortidos', 'sem marca', '40.00', 2, NULL, NULL, NULL, 1, '0'),
(7, 'Roda', 'Roda de carro', 'BMW', '150.00', 0, NULL, NULL, NULL, 1, 'teste'),
(8, 'Roda', 'Roda de carro 17 polegadas', 'FIAT', '150.00', 0, NULL, NULL, NULL, 2, 'teste'),
(11, 'Produto do dellan', 'Descricao do Bem', 'Marca do bem', '100.00', 1, 'URL da Imagem', 'Endereco Fisico', 'Endereco Virtual', 1, '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `conta`
--

CREATE TABLE IF NOT EXISTS `conta` (
`idConta` int(11) NOT NULL,
  `idMembro` int(11) DEFAULT NULL,
  `Login` varchar(45) DEFAULT NULL,
  `Senha` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `conta`
--

INSERT INTO `conta` (`idConta`, `idMembro`, `Login`, `Senha`, `Email`) VALUES
(2, 1, 'Dellan', '3652', 'dellanhoffman'),
(3, 1, 'Dellan', '3652', 'dellanhoffman'),
(4, 1, 'Dellan', '3652', 'dellanhoffman'),
(5, 1, 'Dellan', '3652', 'dellanhoffman'),
(6, 1, 'Dellan', '3652', 'dellanhoffman'),
(7, 1, 'Dellan', '3652', 'dellanhoffman');

-- --------------------------------------------------------

--
-- Estrutura da tabela `entrega`
--

CREATE TABLE IF NOT EXISTS `entrega` (
`idEntrega` int(11) NOT NULL,
  `Transportadora` varchar(45) DEFAULT NULL,
  `Descricao` varchar(45) DEFAULT NULL,
  `idPedido` varchar(45) DEFAULT NULL,
  `DataEntrada` date DEFAULT NULL,
  `DataSaida` date DEFAULT NULL,
  `DataEntrega` date DEFAULT NULL,
  `CodigoRastreio` varchar(45) DEFAULT NULL,
  `idItemPedido` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `estoque`
--

CREATE TABLE IF NOT EXISTS `estoque` (
  `idEstoque` int(11) NOT NULL,
  `Descricao` varchar(45) DEFAULT NULL,
  `Loja_idLoja` int(11) NOT NULL,
  `idBem` int(11) NOT NULL,
  `Qtd` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `itempedido`
--

CREATE TABLE IF NOT EXISTS `itempedido` (
`idItemPedido` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  `DescricaoItem` varchar(200) DEFAULT NULL,
  `QtdItem` int(11) DEFAULT NULL,
  `TipoItem` int(11) DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `itempedido`
--

INSERT INTO `itempedido` (`idItemPedido`, `idPedido`, `DescricaoItem`, `QtdItem`, `TipoItem`, `Valor`) VALUES
(13, 1, 'Detergente Líquido', 4, 0, '4.20'),
(14, 1, '50 salgados sortidos', 2, 0, '40.00'),
(15, 2, 'Roda de carro', 3, 0, '150.00'),
(16, 3, 'Roda de carro 17 polegadas', 3, 0, '150.00'),
(17, 4, 'Descricao do Bem', 4, 0, '100.00'),
(18, 5, 'Roda de carro 17 polegadas', 4, 0, '150.00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `itempedidodeservico`
--

CREATE TABLE IF NOT EXISTS `itempedidodeservico` (
`idItemPedidoDeServico` int(11) NOT NULL,
  `idPedido` int(11) DEFAULT NULL,
  `DescricaoServico` varchar(200) DEFAULT NULL,
  `QtdItem` int(11) DEFAULT NULL,
  `TipoItem` int(11) DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `loja`
--

CREATE TABLE IF NOT EXISTS `loja` (
  `idLoja` int(11) NOT NULL,
  `Descricao` varchar(45) DEFAULT NULL,
  `idMembro` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `loja`
--

INSERT INTO `loja` (`idLoja`, `Descricao`, `idMembro`) VALUES
(1, 'Loja teste', 1),
(2, 'Lojinha', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `membro`
--

CREATE TABLE IF NOT EXISTS `membro` (
`idMembro` int(10) unsigned NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `CPF` varchar(12) NOT NULL,
  `Telefone` varchar(20) DEFAULT NULL,
  `Endereco` varchar(200) DEFAULT NULL,
  `Email` varchar(100) NOT NULL,
  `CodCarterira` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `membro`
--

INSERT INTO `membro` (`idMembro`, `Nome`, `CPF`, `Telefone`, `Endereco`, `Email`, `CodCarterira`) VALUES
(1, 'Dellan Hoffman', '000.554.6544', '(21) 3962-3647', 'Rua Abec', 'dellanhoffman@dell.com.br', 2),
(2, 'Hebert Alves Ferreira', '213123', '2131231', 'Rua teste', 'hebert.ferreira@sga.pucminas.br', 3),
(3, 'Sérgio', '231412', '2312321', 'Rua teste 2', 'sergiovitarellisilva@gmail.com', 42);

-- --------------------------------------------------------

--
-- Estrutura da tabela `moeda`
--

CREATE TABLE IF NOT EXISTS `moeda` (
`idMoeda` int(11) NOT NULL,
  `Descricao` varchar(45) DEFAULT NULL,
  `Codigo` varchar(45) DEFAULT NULL,
  `Pagamento_idPagamento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE IF NOT EXISTS `pagamento` (
`idPagamento` int(11) NOT NULL,
  `idPedido` int(11) DEFAULT NULL,
  `idCliente` int(11) DEFAULT NULL,
  `idMoeda` int(11) DEFAULT NULL,
  `Tipo` int(11) DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamentodebem`
--

CREATE TABLE IF NOT EXISTS `pagamentodebem` (
`idPagamentoBem` int(10) unsigned NOT NULL,
  `idLoja` int(11) DEFAULT NULL,
  `Data` date DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL,
  `idPedidoDeBem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamentodeservico`
--

CREATE TABLE IF NOT EXISTS `pagamentodeservico` (
`idPagamentoServico` int(11) NOT NULL,
  `idLoja` int(11) DEFAULT NULL,
  `Data` date DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL,
  `idPedidoDeServico` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidodebem`
--

CREATE TABLE IF NOT EXISTS `pedidodebem` (
`idPedidoDeBem` int(10) unsigned NOT NULL,
  `idLoja` int(10) unsigned NOT NULL,
  `idMembro` int(10) unsigned NOT NULL,
  `Valor` decimal(18,2) DEFAULT NULL,
  `EnderecoEntrega` varchar(200) DEFAULT NULL,
  `DataPedido` date DEFAULT NULL,
  `DataEntrega` date DEFAULT NULL,
  `Situacao` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pedidodebem`
--

INSERT INTO `pedidodebem` (`idPedidoDeBem`, `idLoja`, `idMembro`, `Valor`, `EnderecoEntrega`, `DataPedido`, `DataEntrega`, `Situacao`) VALUES
(1, 1, 2, '96.80', 'Teste, 123, 123, 123, 123, 123.', '2015-06-12', '2015-06-30', 'INICIADO'),
(2, 1, 2, '450.00', 'Teste, 123, 123, 123, 123, 123.', '2015-06-12', '2015-06-30', 'INICIADO'),
(3, 2, 2, '450.00', 'Teste, 123, 123, 123, 123, 123.', '2015-06-12', '2015-06-30', 'INICIADO'),
(4, 1, 2, '400.00', 'Teste, 123, 123, 123, 123, 123.', '2015-06-12', '2015-06-30', 'INICIADO'),
(5, 2, 2, '600.00', 'Teste, 123, 123, 123, 123, 123.', '2015-06-12', '2015-06-30', 'INICIADO');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidodeservico`
--

CREATE TABLE IF NOT EXISTS `pedidodeservico` (
`idPedidoDeServico` int(11) NOT NULL,
  `idMembro` int(11) DEFAULT NULL,
  `idLoja` int(11) DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL,
  `EnderecoEntrega` varchar(200) DEFAULT NULL,
  `DataPedido` date DEFAULT NULL,
  `DataEntrega` date DEFAULT NULL,
  `Hora` timestamp NULL DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `recebimentodebem`
--

CREATE TABLE IF NOT EXISTS `recebimentodebem` (
`idRecebimentoDeBem` int(10) unsigned NOT NULL,
  `idLoja` int(11) DEFAULT NULL,
  `Data` date DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL,
  `idPedidoDeBem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `recebimentodeservico`
--

CREATE TABLE IF NOT EXISTS `recebimentodeservico` (
`idRecebimentoDeServico` int(11) NOT NULL,
  `idLoja` int(11) DEFAULT NULL,
  `Data` date DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL,
  `idPedidoDeServico` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico`
--

CREATE TABLE IF NOT EXISTS `servico` (
`idServico` int(11) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `DescricaoDeServico` varchar(45) DEFAULT NULL,
  `Valor` decimal(18,2) DEFAULT NULL,
  `FormaPagamento` varchar(45) DEFAULT NULL,
  `Telefone` varchar(45) DEFAULT NULL,
  `Categoria` varchar(45) DEFAULT NULL,
  `UrlImagem` varchar(200) DEFAULT NULL,
  `CodPrestador` int(11) DEFAULT NULL COMMENT 'Pode ser o idCliente',
  `EnderecoFisito` varchar(100) DEFAULT NULL,
  `EnderecoDigital` varchar(200) DEFAULT NULL,
  `idLoja` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agenda`
--
ALTER TABLE `agenda`
 ADD PRIMARY KEY (`idAgenda`), ADD KEY `fk_Agenda_ItemPedidoDeServico1` (`idItemPedidoDeServico`), ADD KEY `fk_Agenda_Loja1` (`idLoja`);

--
-- Indexes for table `bem`
--
ALTER TABLE `bem`
 ADD PRIMARY KEY (`idBem`), ADD UNIQUE KEY `idBem_UNIQUE` (`idBem`), ADD KEY `fk_Bem_Loja1` (`idLoja`);

--
-- Indexes for table `conta`
--
ALTER TABLE `conta`
 ADD PRIMARY KEY (`idConta`), ADD UNIQUE KEY `idConta_UNIQUE` (`idConta`);

--
-- Indexes for table `entrega`
--
ALTER TABLE `entrega`
 ADD PRIMARY KEY (`idEntrega`), ADD UNIQUE KEY `idTransportadora_UNIQUE` (`idEntrega`), ADD KEY `fk_Entrega_ItemPedido1` (`idItemPedido`);

--
-- Indexes for table `estoque`
--
ALTER TABLE `estoque`
 ADD PRIMARY KEY (`idEstoque`), ADD KEY `fk_Estoque_Loja1` (`Loja_idLoja`);

--
-- Indexes for table `itempedido`
--
ALTER TABLE `itempedido`
 ADD PRIMARY KEY (`idItemPedido`), ADD UNIQUE KEY `idItemPedido_UNIQUE` (`idItemPedido`);

--
-- Indexes for table `itempedidodeservico`
--
ALTER TABLE `itempedidodeservico`
 ADD PRIMARY KEY (`idItemPedidoDeServico`), ADD UNIQUE KEY `idItemPedido_UNIQUE` (`idItemPedidoDeServico`), ADD KEY `fk_ItemPedidoDeServico_PedidoDeServico1` (`idPedido`);

--
-- Indexes for table `loja`
--
ALTER TABLE `loja`
 ADD PRIMARY KEY (`idLoja`), ADD UNIQUE KEY `idMembro_UNIQUE` (`idMembro`);

--
-- Indexes for table `membro`
--
ALTER TABLE `membro`
 ADD PRIMARY KEY (`idMembro`), ADD UNIQUE KEY `idMembro_UNIQUE` (`idMembro`);

--
-- Indexes for table `moeda`
--
ALTER TABLE `moeda`
 ADD PRIMARY KEY (`idMoeda`), ADD UNIQUE KEY `idMoeda_UNIQUE` (`idMoeda`), ADD KEY `fk_Moeda_Pagamento1` (`Pagamento_idPagamento`);

--
-- Indexes for table `pagamento`
--
ALTER TABLE `pagamento`
 ADD PRIMARY KEY (`idPagamento`), ADD UNIQUE KEY `idPagamento_UNIQUE` (`idPagamento`);

--
-- Indexes for table `pagamentodebem`
--
ALTER TABLE `pagamentodebem`
 ADD PRIMARY KEY (`idPagamentoBem`), ADD KEY `fk_PagamentoDeBem_Loja1` (`idLoja`);

--
-- Indexes for table `pagamentodeservico`
--
ALTER TABLE `pagamentodeservico`
 ADD PRIMARY KEY (`idPagamentoServico`), ADD UNIQUE KEY `idPagamentoBem_UNIQUE` (`idPagamentoServico`), ADD KEY `fk_PagamentoDeServico_PedidoDeServico1` (`idPedidoDeServico`), ADD KEY `fk_PagamentoDeServico_Loja1` (`idLoja`);

--
-- Indexes for table `pedidodebem`
--
ALTER TABLE `pedidodebem`
 ADD PRIMARY KEY (`idPedidoDeBem`), ADD UNIQUE KEY `idPedido_UNIQUE` (`idPedidoDeBem`), ADD KEY `fk_PedidoDeBem_Membro1` (`idMembro`);

--
-- Indexes for table `pedidodeservico`
--
ALTER TABLE `pedidodeservico`
 ADD PRIMARY KEY (`idPedidoDeServico`), ADD UNIQUE KEY `idPedido_UNIQUE` (`idPedidoDeServico`), ADD KEY `fk_PedidoDeServico_Loja1` (`idLoja`);

--
-- Indexes for table `recebimentodebem`
--
ALTER TABLE `recebimentodebem`
 ADD PRIMARY KEY (`idRecebimentoDeBem`), ADD UNIQUE KEY `idRecebimentoDeBem_UNIQUE` (`idRecebimentoDeBem`), ADD KEY `fk_RecebimentoDeBem_Loja1` (`idLoja`);

--
-- Indexes for table `recebimentodeservico`
--
ALTER TABLE `recebimentodeservico`
 ADD PRIMARY KEY (`idRecebimentoDeServico`), ADD UNIQUE KEY `idRecebimentoDeServico_UNIQUE` (`idRecebimentoDeServico`), ADD KEY `fk_RecebimentoDeServico_Loja1` (`idLoja`), ADD KEY `fk_RecebimentoDeServico_PedidoDeServico1` (`idPedidoDeServico`);

--
-- Indexes for table `servico`
--
ALTER TABLE `servico`
 ADD PRIMARY KEY (`idServico`), ADD UNIQUE KEY `idDescricaoDeServico_UNIQUE` (`idServico`), ADD KEY `fk_Servico_Loja1` (`idLoja`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bem`
--
ALTER TABLE `bem`
MODIFY `idBem` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `conta`
--
ALTER TABLE `conta`
MODIFY `idConta` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `entrega`
--
ALTER TABLE `entrega`
MODIFY `idEntrega` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `itempedido`
--
ALTER TABLE `itempedido`
MODIFY `idItemPedido` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `itempedidodeservico`
--
ALTER TABLE `itempedidodeservico`
MODIFY `idItemPedidoDeServico` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `membro`
--
ALTER TABLE `membro`
MODIFY `idMembro` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `moeda`
--
ALTER TABLE `moeda`
MODIFY `idMoeda` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pagamento`
--
ALTER TABLE `pagamento`
MODIFY `idPagamento` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pagamentodebem`
--
ALTER TABLE `pagamentodebem`
MODIFY `idPagamentoBem` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pagamentodeservico`
--
ALTER TABLE `pagamentodeservico`
MODIFY `idPagamentoServico` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pedidodebem`
--
ALTER TABLE `pedidodebem`
MODIFY `idPedidoDeBem` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pedidodeservico`
--
ALTER TABLE `pedidodeservico`
MODIFY `idPedidoDeServico` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `recebimentodebem`
--
ALTER TABLE `recebimentodebem`
MODIFY `idRecebimentoDeBem` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `recebimentodeservico`
--
ALTER TABLE `recebimentodeservico`
MODIFY `idRecebimentoDeServico` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `servico`
--
ALTER TABLE `servico`
MODIFY `idServico` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `agenda`
--
ALTER TABLE `agenda`
ADD CONSTRAINT `fk_Agenda_ItemPedidoDeServico1` FOREIGN KEY (`idItemPedidoDeServico`) REFERENCES `itempedidodeservico` (`idItemPedidoDeServico`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Agenda_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `bem`
--
ALTER TABLE `bem`
ADD CONSTRAINT `fk_Bem_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `entrega`
--
ALTER TABLE `entrega`
ADD CONSTRAINT `fk_Entrega_ItemPedido1` FOREIGN KEY (`idItemPedido`) REFERENCES `itempedido` (`idItemPedido`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `estoque`
--
ALTER TABLE `estoque`
ADD CONSTRAINT `fk_Estoque_Loja1` FOREIGN KEY (`Loja_idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `itempedidodeservico`
--
ALTER TABLE `itempedidodeservico`
ADD CONSTRAINT `fk_ItemPedidoDeServico_PedidoDeServico1` FOREIGN KEY (`idPedido`) REFERENCES `pedidodeservico` (`idPedidoDeServico`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `loja`
--
ALTER TABLE `loja`
ADD CONSTRAINT `fk_Loja_Membro1` FOREIGN KEY (`idMembro`) REFERENCES `membro` (`idMembro`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `moeda`
--
ALTER TABLE `moeda`
ADD CONSTRAINT `fk_Moeda_Pagamento1` FOREIGN KEY (`Pagamento_idPagamento`) REFERENCES `pagamento` (`idPagamento`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pagamentodebem`
--
ALTER TABLE `pagamentodebem`
ADD CONSTRAINT `fk_PagamentoDeBem_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pagamentodeservico`
--
ALTER TABLE `pagamentodeservico`
ADD CONSTRAINT `fk_PagamentoDeServico_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_PagamentoDeServico_PedidoDeServico1` FOREIGN KEY (`idPedidoDeServico`) REFERENCES `pedidodeservico` (`idPedidoDeServico`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pedidodebem`
--
ALTER TABLE `pedidodebem`
ADD CONSTRAINT `fk_PedidoDeBem_Membro1` FOREIGN KEY (`idMembro`) REFERENCES `membro` (`idMembro`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pedidodeservico`
--
ALTER TABLE `pedidodeservico`
ADD CONSTRAINT `fk_PedidoDeServico_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `recebimentodebem`
--
ALTER TABLE `recebimentodebem`
ADD CONSTRAINT `fk_RecebimentoDeBem_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `recebimentodeservico`
--
ALTER TABLE `recebimentodeservico`
ADD CONSTRAINT `fk_RecebimentoDeServico_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_RecebimentoDeServico_PedidoDeServico1` FOREIGN KEY (`idPedidoDeServico`) REFERENCES `pedidodeservico` (`idPedidoDeServico`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `servico`
--
ALTER TABLE `servico`
ADD CONSTRAINT `fk_Servico_Loja1` FOREIGN KEY (`idLoja`) REFERENCES `loja` (`idLoja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
